<html>
<head>
	<title>Notas</title>
	<meta charset="utf8">
</head>
<body>

<!-- formulario que recibe el identificador de una nota, el nombre de una nota, u el porcentaje de una nota para registrarla como una nueva nota -->
<form name="formulario prueba" id="formulario" method="POST" action="includes/crearnota.php">
	<label>Identificador de la nota:  </label><input type="text" name="idnota" id="idnota"> 
	<label>Nombre de la nota:	</label><input type="text" name="nombrenota" id="nombrenota">
	<label>Porcentaje de la nota:</label><input type="text" name="porcentaje" id="porcentaje">
	<input type="submit" value="Enviar">
</form>

<?php 
include_once("includes/database.php");
// selecciona todo los campos de la tabla de notas
$query = "SELECT * FROM estudiantes.notas";
$resultado=mysqli_query($conexion,$query);

// hace una tabla en la que organiza los datos recibidos del sql
// en esta página encontre como organizar la tabla: http://www.elticus.com/?contenido=113
echo" <table border=1 cellpadding=4 cellspacing=0> <tr>   <th>Codigo Nota</th>  <th>Nombre Nota</th>   <th>Porcentaje de la Nota</th></tr>";
while ($row = mysqli_fetch_array($resultado)) {
	echo "<tr><td>".$row["IdNota"]."</td><td>".$row["nombre"]."</td><td>".$row["Porcentaje"]."</td></tr>";
}
echo "</table>";

?>
</body>
</html>