<html>
<head>
	<title>Index</title>
	<meta charset="utf8">
</head>
<body>
</br>
<!-- enlaces a las tablas -->
<h2> <a href="estudiantes.php">Tabla de estudiantes</a></h2></br>
<h2> <a href="notas.php">Tabla de notas</a></h2></br>
<h2> <a href="notasestudiantes.php">Tabla de calificaciones</a></h2></br>
<h2> <a href="notasdeestudiantes.php">Tabla de calificaciones de estudiantes</a></h2></br>

</body>
</html>