
<html>
<head>
	<title>Estudiantes</title>
	<meta charset="utf8">
</head>
<body>

<!-- formulario que recibe el código de un estudiante, el nombre y apellido del estudiante, y su correo para registrarlo como un nuevo estudiantes -->
<form name="formulario prueba" id="formulario" method="POST" action="includes/crearestudiante.php">
<label>Código:  </label><input type="text" name="cod" id="cod"> 
<label>Nombre:	</label><input type="text" name="nombre" id="nombre">
<label>apellido:</label><input type="text" name="apellido" id="apellido">
<label>Correo:	</label><input type="text" name="correo" id="correo">
 <input type="submit" value="Enviar">
</form>

<?php 
include_once("includes/database.php");

// selecciona todo los campos de la tabla de estudiantes
$query = "SELECT * FROM estudiantes.estudiantes";
$resultado=mysqli_query($conexion,$query);
echo" <table border=1 cellpadding=4 cellspacing=0> <tr>   <th>Codigo</th>  <th>Nombre</th>   <th>Apellido</th>   <th>Correo</th> </tr>";


// hace una tabla en la que organiza los datos recibidos del sql
// en esta página encontre como organizar la tabla: http://www.elticus.com/?contenido=113
while ($row = mysqli_fetch_array($resultado)) {
	echo "<tr><td> <a href='includes/tablaestudiante.php?cod=".$row['Codigo']."'>".$row['Codigo']."</a> </td><td>".$row['Nombre']."</td><td>".$row['Apellido']."</td><td>".$row['Correo']."</td></tr>";
}
echo "</table>";
?>
</body>
</html>