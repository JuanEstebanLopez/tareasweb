<?php
// revisa si se reciven datos
if(isset($_POST) and $_POST["nombre"] <> ""){
$nombre = $_POST["nombre"];
$cod = $_POST['cod'];
$apellido = $_POST["apellido"];
$correo = $_POST["correo"];

include_once("database.php");
// registra un estudiante con los datos obtenidos
$query = "INSERT INTO estudiantes.estudiantes(`Codigo`, `Nombre`, `Apellido`, `Correo`) VALUES ('".$cod."','".$nombre."','".$apellido."','".$correo."')";

mysqli_query($conexion,$query);
}
// vuelve a la tabla de estudiantes
header ("Location: ../estudiantes.php");

?>