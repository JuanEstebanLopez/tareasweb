<html>
<head>
	<title>Estudiantes</title>
	<meta charset="utf8">
</head>
<body>
<!-- formulario que recibe el código del estudiante para mostrar la tabla de notas del estudiante -->
<form name="notas de estudiante" id="bucar notas" method="GET" action="tablaestudiante.php">
<label>Código:  </label><input type="text" name="cod" id="cod"> 
 <input type="submit" value="Enviar">
</form>


<?php
// revisa si se reciven datos
if(isset($_GET) AND $_GET["cod"]<>""){

$codigo = $_GET["cod"];

include_once("database.php");

// selecciona el nombre correspondiente al código
$query= "SELECT Nombre from estudiantes.estudiantes WHERE Codigo='".$codigo."'";
$resultado=mysqli_query($conexion,$query);

echo "<h3>Notas de ".mysqli_fetch_array($resultado)["Nombre"].":</h3>";

// muestra una tabla correspondiente a las notas del código recivido
$query = "SELECT notas.nombre As nota, notasEstudiantes.valorNota As calificacion FROM estudiantes.estudiantes join estudiantes.notas join estudiantes.notasestudiantes on estudiantes.Codigo=notasestudiantes.CodEstudiante and notas.IdNota=notasestudiantes.IdNota  WHERE estudiantes.Codigo='".$codigo."'";

$resultado=mysqli_query($conexion,$query);
// hace una tabla en la que organiza los datos recibidos del sql
// en esta página encontre como organizar la tabla: http://www.elticus.com/?contenido=113
echo" <table border=1 cellpadding=4 cellspacing=0> <tr>   <th>Nota</th>  <th>Calificacion</th>  </tr>";
while ($row = mysqli_fetch_array($resultado)) {
	echo "<tr><td>".$row['nota']."</td><td>".$row['calificacion']."</td></tr>";
}
echo "</table>";
}else{ 
	// si no se recive ningún dato va a la tabla de notas de todos los estudiantes
header ("Location: ../notasdeestudiantes.php");
}

?>
</body>
</html>