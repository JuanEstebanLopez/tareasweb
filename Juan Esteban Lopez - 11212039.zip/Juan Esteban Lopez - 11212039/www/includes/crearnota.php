<?php
// revisa si se reciven datos
if(isset($_POST) and $_POST["idnota"] <> ""){
$id = $_POST["idnota"];
$nom = $_POST['nombrenota'];
$por = $_POST["porcentaje"];

include_once("database.php");
// registra una nueva nota con los datos obtenidos
$query ="INSERT INTO estudiantes.notas(`IdNota`, `nombre`, `Porcentaje`) VALUES ('".$id."','".$nom."','".$por."')";
mysqli_query($conexion,$query);
}
// vuelve a la tabla de notas
header ("Location: ../notas.php");

?>