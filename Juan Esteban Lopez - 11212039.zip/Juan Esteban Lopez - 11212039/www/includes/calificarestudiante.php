<?php
// revisa si se reciven datos
if(isset($_POST) and $_POST["id"] <> ""){
$cod = $_POST['cod'];
$id = $_POST["id"];
$cal = $_POST["cal"];

include_once("database.php");
// registra una nueva calificación con los datos obtenidos
$query ="INSERT INTO estudiantes.notasestudiantes(`CodEstudiante`, `IdNota`, `valorNota`) VALUES ('".$cod."','".$id."','".$cal."')";
mysqli_query($conexion,$query);
}
// vuelve a la tabla de notas de los estudiantes
header ("Location: ../notasestudiantes.php");

?>