<html>
<head>
	<title>Notas de Estudiantes</title>
	<meta charset="utf8">
</head>
<body>

<?php 
include_once("includes/database.php");

// selecciona los nombre de las notas
$query= "SELECT nombre FROM estudiantes.notas";
$nota=mysqli_query($conexion,$query);

// hace un arreglo que guarde el nombre de las notas
for ($i=0; $nombreNotas=mysqli_fetch_array($nota); $i++) { 
	$nomNota[$i]=$nombreNotas["nombre"];
}

// selecciona el nombre de el los estudiantes y sus notas (sumando sus notas con 0), y luego separa los datos por nombre, usa un for que recorre el arreglo de notas anteriormente creado, para así poder obtener todas las notas. y construye ua tabla con los datos recibidos
// en esta página encontré como organizar las notas: http://cesar.bevia.net/como-pivotar-datos-consultas-sql/
$q = "SELECT estudiantes.Nombre AS nombre";
for ($i=0; $i <sizeof($nomNota) ; $i++) { 
$q=$q.", sum( if( notas.nombre='".$nomNota[$i]."', notasEstudiantes.valorNota, 0) )as '".$nomNota[$i]."'";
echo $nombreNotas["nombre"];
}
 $q=$q." FROM estudiantes.estudiantes join estudiantes.notas join estudiantes.notasestudiantes on estudiantes.Codigo=notasestudiantes.CodEstudiante and notas.IdNota=notasestudiantes.IdNota 
 group by nombre";

 $resultado=mysqli_query($conexion,$q);

// hace una tabla en la que organiza los datos recibidos del sql
// en esta página encontre como organizar la tabla: http://www.elticus.com/?contenido=113
echo" <table border=1 cellpadding=4 cellspacing=0> <tr>   <th>Nombre</th>";
//  se recorre el arreglo de los nombres de notas para ponerlas como títulos de las tablas
for ($i=0; $i < sizeof($nomNota); $i++) { 
	echo "<th>".$nomNota[$i]."</th>";	
}

echo "</tr>";
// se recorre el arreglo de los nombres de las notas para llenar los campos de las notas
while ($row = mysqli_fetch_array($resultado)) {
	echo "<tr><td>".$row["nombre"]."</td>";
for ($i=0; $i < sizeof($nomNota); $i++) { 
	echo "<td>".$row[$nomNota[$i]]."</td>";
}
echo "</tr>";
}
echo "</table>";

?>


</body>

</html>