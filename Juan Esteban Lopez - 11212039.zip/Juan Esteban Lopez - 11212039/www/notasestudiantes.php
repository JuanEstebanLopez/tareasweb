<html>
<head>
	<title>Notas Estudiantes</title>
	<meta charset="utf8">
</head>
<body>

<!-- formulario que recibe el código de un estudiante, el nombre de una nota, y la calificación para registrarla como una nueva calificación -->
<form name="formulario prueba" id="formulario" method="POST" action="includes/calificarestudiante.php">
<label>Código del estudiante:	</label><input type="text" name="cod" id="cod">
<label>Identificador de la nota:  </label><input type="text" name="id" id="id"> 
<label>Calificación:</label><input type="text" name="cal" id="cal">
 <input type="submit" value="Enviar">
</form>


<?php 
include_once("includes/database.php");
// selecciona todo los campos de la tabla de notasestudiantes
$query = "SELECT * FROM estudiantes.notasestudiantes";
$resultado=mysqli_query($conexion,$query);
echo" <table border=1 cellpadding=4 cellspacing=0> <tr>   <th>Codigo Estudiante</th>  <th>Codigo Nota</th>   <th>Calificacion</th></tr>";

// hace una tabla en la que organiza los datos recibidos del sql
// en esta página encontre como organizar la tabla: http://www.elticus.com/?contenido=113
while ($row = mysqli_fetch_array($resultado)) {
	echo  "<tr><td> <a href='includes/tablaestudiante.php?cod=".$row['CodEstudiante']."'>".$row["CodEstudiante"]."</a> </td><td>".$row["IdNota"]."</td><td>".$row["valorNota"]."</td></tr>";
}
echo "</table>";
?>

</body>

</html>