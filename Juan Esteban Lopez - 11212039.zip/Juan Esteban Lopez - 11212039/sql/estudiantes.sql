-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-09-2014 a las 02:26:22
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `estudiantes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE IF NOT EXISTS `estudiantes` (
  `Codigo` varchar(8) COLLATE utf8_spanish_ci NOT NULL,
  `Nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `Apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `Correo` varchar(30) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`Codigo`, `Nombre`, `Apellido`, `Correo`) VALUES
('11212039', 'Juan Esteban', 'López Garcia', 'jua'),
('11212041', 'Nicodemus', 'Luna Rojas', 'nic'),
('11212023', 'Natalia', 'Ayala Perez', 'nat'),
('asdads', 'saddas', 'dasadsasd', 'dasasddas'),
('11212046', 'Johan', 'Ramirez', 'jujtjrgbf@jut.com'),
('11212036', 'pepito', 'perez', 'pepitoperez@hotmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE IF NOT EXISTS `notas` (
  `IdNota` varchar(8) COLLATE utf8_spanish_ci NOT NULL DEFAULT '',
  `nombre` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Porcentaje` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdNota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`IdNota`, `nombre`, `Porcentaje`) VALUES
('0001', 'Tarea en c', 1),
('0002', 'Taller 1', 10),
('0003', 'Parcial 1', 20),
('0004', 'Taller 2', 10),
('0005', 'quiz', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notasestudiantes`
--

CREATE TABLE IF NOT EXISTS `notasestudiantes` (
  `CodEstudiante` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `IdNota` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `valorNota` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `notasestudiantes`
--

INSERT INTO `notasestudiantes` (`CodEstudiante`, `IdNota`, `valorNota`) VALUES
('11212039', '0002', 3),
('11212039', '0001', 4),
('11212039', '0003', 2),
('11212041', '0002', 4),
('11212041', '0001', 4),
('11212041', '0003', 3),
('11212023', '0002', 2),
('11212023', '0001', 5),
('11212023', '0003', 3),
('11212046', '0001', 4),
('11212046', '0002', 3),
('11212046', '0003', 5),
('', '0004', 4),
('', '0004', 4),
('', '0004', 4),
('11212036', '0004', 4),
('11212039', '0005', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tabla`
--

CREATE TABLE IF NOT EXISTS `tabla` (
  `nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `Taller 1` double DEFAULT NULL,
  `Tarea en casa` double DEFAULT NULL,
  `Parcial 1` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tabla`
--

INSERT INTO `tabla` (`nombre`, `Taller 1`, `Tarea en casa`, `Parcial 1`) VALUES
('Juan Esteban', 3, 4, 2),
('Natalia', 2, 5, 3),
('Nicodemus', 4, 4, 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
